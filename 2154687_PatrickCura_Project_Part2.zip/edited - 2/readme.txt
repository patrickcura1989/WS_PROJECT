Please open any of the html files to check the project.
Homepage is home.html